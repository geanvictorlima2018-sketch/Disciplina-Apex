# Disciplina Apex — como colocar no ar (site + app instalável)

Isso aqui é **um projeto só**. Front, back e PWA já estão juntos e conectados.
Você não precisa juntar nada — só publicar essa pasta inteira.

## Caminho mais simples (sem usar terminal)

1. Crie uma conta gratuita em **github.com** (se ainda não tiver)
2. Crie um repositório novo e faça upload de **todos os arquivos desta pasta**
   (no GitHub tem um botão "Add file → Upload files" — arrasta tudo)
3. Crie uma conta gratuita em **vercel.com** e clique em "Add New → Project"
4. Escolha o repositório que você acabou de criar → clique em "Deploy"
5. Em 1-2 minutos a Vercel te dá um link, algo como `disciplina-apex.vercel.app`
   → **isso já é o site no ar**, funcionando, com onboarding e painel

## Para os botões de Pix e o e-mail de boas-vindas funcionarem de verdade

Sem isso, o app funciona 100% (onboarding, metas, água, tarefas, streak) —
só o Pix e o e-mail automático ficam "de mentira" até você conectar:

1. Crie uma conta em **asaas.com.br** → pegue sua API Key em Integrações
2. Crie uma conta em **resend.com** → pegue sua API Key
3. No painel da Vercel: Settings → Environment Variables → cole as chaves
   (os nomes exatos estão no arquivo `.env.example` desta pasta)
4. Clique em "Redeploy" pra aplicar

## Para virar "um app" de verdade no celular

Isso já é um PWA (Progressive Web App) — não precisa de loja de aplicativos:

1. Abra o link do seu site (`seu-app.vercel.app`) no Chrome do Android
2. Depois de navegar um pouco, vai aparecer um banner "Instalar Apex na tela inicial"
   dentro do próprio app (já vem pronto no painel)
3. No iPhone (Safari): toque em Compartilhar → "Adicionar à Tela de Início"

A partir daí ele abre como app, tela cheia, ícone próprio, sem barra do navegador.

## Se quiser testar no seu computador antes de publicar
```
npm install
npm run dev
```
Abre em `http://localhost:5173`

## O que já vem pronto dentro dessa pasta
- `src/App.jsx` — app inteiro (onboarding + painel + metas + Pix)
- `api/` — as rotas que falam com Asaas e Resend (já conectadas ao front)
- `public/manifest.json` + `service-worker.js` + ícones — já configurados pro app instalar
- Dados do usuário salvos no próprio navegador dele (cada pessoa começa do zero)
