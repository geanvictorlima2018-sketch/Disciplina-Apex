// useInstallPrompt.js
// Hook para controlar o pop-up nativo "Adicionar à tela inicial" no Android/Chrome.
//
// IMPORTANTE — o que dá pra "forçar" e o que não dá:
// O Chrome só dispara 'beforeinstallprompt' se TODOS os critérios forem atendidos:
//   1. manifest.json válido, servido com Content-Type: application/manifest+json (ou vazio, funciona também)
//   2. Site em HTTPS
//   3. Service Worker registrado com um handler de 'fetch'
//   4. Ícones 192px e 512px presentes e acessíveis
//   5. O usuário ainda não instalou nem dispensou o prompt recentemente
//   6. Um mínimo de engajamento do usuário com o site (heurística do Chrome, não controlável via código)
// Não existe API para forçar o navegador a abrir o prompt sem esses critérios —
// o que este hook faz é capturar o evento QUANDO ele acontece e permitir
// disparar o prompt no momento certo da sua UX (ex: depois do onboarding).

import { useEffect, useState, useCallback } from "react";

export function useInstallPrompt() {
  const [deferredEvent, setDeferredEvent] = useState(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    function onBeforeInstallPrompt(e) {
      e.preventDefault(); // impede o mini-infobar automático do Chrome
      setDeferredEvent(e); // guarda o evento pra disparar depois, no seu botão
    }
    function onAppInstalled() {
      setInstalled(true);
      setDeferredEvent(null);
    }

    window.addEventListener("beforeinstallprompt", onBeforeInstallPrompt);
    window.addEventListener("appinstalled", onAppInstalled);

    // Registra o Service Worker (requisito para o prompt disparar)
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/service-worker.js").catch(console.error);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstallPrompt);
      window.removeEventListener("appinstalled", onAppInstalled);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!deferredEvent) return { outcome: "unavailable" };
    deferredEvent.prompt();
    const choice = await deferredEvent.userChoice; // { outcome: 'accepted' | 'dismissed' }
    setDeferredEvent(null);
    return choice;
  }, [deferredEvent]);

  return { canInstall: !!deferredEvent, installed, promptInstall };
}

/* Uso no componente:
   const { canInstall, promptInstall } = useInstallPrompt();
   {canInstall && <button onClick={promptInstall}>Instalar Apex</button>}
*/
