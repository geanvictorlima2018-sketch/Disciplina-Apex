// api/pix/create.js  (Vercel: rota fica em /api/pix/create)
const {
  findOrCreateCustomer,
  createSubscriptionWithTrial,
  getPixQrCode,
  getSubscriptionPayments,
} = require("../../lib/asaas");

const PLAN_PRICES = {
  premium_mensal: 29.9,
};

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Método não permitido" });

  try {
    const { plan, name, email, cpfCnpj } = req.body;
    const value = PLAN_PRICES[plan];
    if (!value) return res.status(400).json({ error: "Plano inválido" });
    if (!email || !name) return res.status(400).json({ error: "name e email são obrigatórios" });

    // 1. Cliente no Asaas
    const customer = await findOrCreateCustomer({ name, email, cpfCnpj });

    // 2. Assinatura com 1ª cobrança agendada para dentro de 7 dias (trial)
    const subscription = await createSubscriptionWithTrial({ customerId: customer.id, value });

    // 3. Busca a cobrança (payment) gerada pela assinatura para obter o QR Code Pix
    const payments = await getSubscriptionPayments(subscription.id);
    const firstPayment = payments?.data?.[0];
    if (!firstPayment) throw new Error("Assinatura criada, mas nenhuma cobrança foi gerada ainda.");

    const pix = await getPixQrCode(firstPayment.id);

    // TODO: salvar no seu banco -> { userId, subscriptionId, paymentId, trialEndsAt, status: 'trialing' }

    return res.status(200).json({
      subscriptionId: subscription.id,
      paymentId: firstPayment.id,
      trialEndsAt: subscription.nextDueDate,
      qrCodeImage: pix.encodedImage, // base64 — o front renderiza como <img>
      payload: pix.payload, // código "copia e cola"
      expirationDate: pix.expirationDate,
    });
  } catch (err) {
    console.error("[pix/create]", err);
    return res.status(err.status || 500).json({ error: err.message || "Erro ao gerar Pix" });
  }
};
