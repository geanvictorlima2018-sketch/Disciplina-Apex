// api/subscription/cancel.js
const { cancelSubscription } = require("../../lib/asaas");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Método não permitido" });

  try {
    const { subscriptionId } = req.body;
    if (!subscriptionId) return res.status(400).json({ error: "subscriptionId é obrigatório" });

    await cancelSubscription(subscriptionId);

    // TODO: atualizar no seu banco -> status: 'cancelled', cancelledAt: now()
    // Importante: se o cancelamento ocorrer DENTRO dos 7 dias de trial,
    // nenhuma cobrança chegou a ser efetivada — o Asaas simplesmente remove
    // a próxima cobrança agendada.

    return res.status(200).json({ ok: true, message: "Assinatura cancelada. Nenhuma cobrança futura será feita." });
  } catch (err) {
    console.error("[subscription/cancel]", err);
    return res.status(err.status || 500).json({ error: err.message || "Erro ao cancelar assinatura" });
  }
};
