// api/asaas/webhook.js
// Configure essa URL em: Asaas > Integrações > Webhooks
// Eventos recomendados: PAYMENT_CONFIRMED, PAYMENT_RECEIVED, PAYMENT_OVERDUE, PAYMENT_DELETED

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  // Segurança básica: valide o token que você configurou no painel do Asaas
  const token = req.headers["asaas-access-token"];
  if (process.env.ASAAS_WEBHOOK_TOKEN && token !== process.env.ASAAS_WEBHOOK_TOKEN) {
    return res.status(401).json({ error: "Token inválido" });
  }

  const { event, payment } = req.body;

  switch (event) {
    case "PAYMENT_CONFIRMED":
    case "PAYMENT_RECEIVED":
      // TODO: marcar assinatura como 'active' no seu banco, liberar acesso Premium
      console.log(`[asaas] Pagamento confirmado: ${payment?.id}`);
      break;
    case "PAYMENT_OVERDUE":
      // TODO: marcar como 'overdue', avisar usuário
      console.log(`[asaas] Pagamento vencido: ${payment?.id}`);
      break;
    case "PAYMENT_DELETED":
      // TODO: cancelamento feito direto no Asaas — sincronizar status
      console.log(`[asaas] Cobrança removida: ${payment?.id}`);
      break;
    default:
      console.log(`[asaas] Evento não tratado: ${event}`);
  }

  return res.status(200).json({ received: true });
};
