// api/email/welcome.js
// Usa a Resend (resend.com) — free tier cobre um app iniciando.
// Alternativas: SendGrid, Amazon SES, Postmark (troque só a chamada fetch abaixo).

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const FROM_ADDRESS = process.env.EMAIL_FROM || "Disciplina Apex <bemvindo@disciplinaapex.com>";

function welcomeEmailHtml(nome) {
  return `
  <div style="background:#000;padding:40px 20px;font-family:'Helvetica Neue',Arial,sans-serif;">
    <div style="max-width:480px;margin:0 auto;background:#0A0A0A;border:1px solid #1E1E1E;border-radius:16px;padding:32px;">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:24px;">
        <span style="width:10px;height:10px;border-radius:50%;background:#C6FF00;display:inline-block;"></span>
        <span style="color:#7A7A7A;font-size:11px;letter-spacing:2px;">DISCIPLINA APEX</span>
      </div>
      <h1 style="color:#fff;font-size:24px;margin:0 0 12px;">Bem-vindo(a), ${nome} 👊</h1>
      <p style="color:#B5B5B5;font-size:14px;line-height:1.6;margin:0 0 24px;">
        Sua conta foi criada com sucesso. Seu painel já está pronto com suas metas
        personalizadas de hidratação, sono, tarefas e foco.
      </p>
      <a href="https://disciplinaapex.com/dashboard"
         style="display:inline-block;background:#C6FF00;color:#000;text-decoration:none;
                font-weight:600;padding:12px 24px;border-radius:10px;font-size:14px;">
        Abrir meu painel
      </a>
      <p style="color:#555;font-size:12px;margin-top:32px;">
        Se você não criou essa conta, ignore este e-mail.
      </p>
    </div>
  </div>`;
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Método não permitido" });

  try {
    const { nome, email } = req.body;
    if (!nome || !email) return res.status(400).json({ error: "nome e email são obrigatórios" });

    if (!RESEND_API_KEY) {
      console.warn("[email/welcome] RESEND_API_KEY não configurada — e-mail não enviado (modo dev).");
      return res.status(200).json({ ok: true, skipped: true });
    }

    const resp = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: FROM_ADDRESS,
        to: email,
        subject: "Bem-vindo(a) ao Disciplina Apex 🔥",
        html: welcomeEmailHtml(nome),
      }),
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err?.message || "Falha ao enviar e-mail");
    }

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error("[email/welcome]", err);
    return res.status(500).json({ error: err.message });
  }
};
